﻿Imports Aankopen.data
Imports System.Data.Common

Public Class ProductDA
    '-- Internal types --
    '-- Fields --
    '-- Properties --
    '-- Constructors --
    Private Sub New()
    End Sub
    '-- Methods --
    Public Shared Function GetProducten(ByVal sProductId As String) As Product
        Dim oDR As DbDataReader = Nothing

        Try
            '1. Select en pars
            Dim sSQL As String = "SELECT * FROM Product WHERE ProductID=?"
            Dim oProductIdPar As DbParameter = Database.GetParameter("ProductID", sProductId)
            oDR = Database.GetDR(sSQL, oProductIdPar)

            '2. Geselecteerde data verwerken
            While oDR.Read()
                Return vulProduct(oDR, sProductId)
            End While

        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Throw

        Finally
            '4. Reader sluiten
            If oDR IsNot Nothing Then
                oDR.Close()
            End If
        End Try
    End Function

    Public Shared Function vulProduct(ByVal oDR As DbDataReader, ByVal productId As String)
        Dim oProduct As New Product(productId)

        oProduct.ID = Convert.ToString(oDR.Item("ProductID"))
        oProduct.Naam = Convert.ToString(oDR.Item("Naam"))
        oProduct.Omschrijving = Convert.ToString(oDR.Item("ExtraOmschrijving"))
        oProduct.Categorie = CategorieDA.GetCategoriesByCategorieId(oDR.Item("CategorieID"))

        Return oProduct
    End Function
    '-- Events --

End Class
