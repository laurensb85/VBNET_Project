﻿Imports Aankopen.data
Imports System.Data.Common

Public Class WarenhuisDA

    '-- Internal types --
    '-- Fields --
    Private Shared warenhuizen As Dictionary(Of String, Warenhuis) = Nothing
    '-- Properties --
    '-- Constructors --
    Private Sub New()
    End Sub
    '-- Methods --
    Public Shared Function GetWarenhuizen() As Dictionary(Of String, Warenhuis)
        If warenhuizen IsNot Nothing Then Return warenhuizen
        '1. Data ophalen
        Dim sSQL As String = "SELECT * FROM Warenhuis"
        Dim oDataTable As DataTable = Database.GetDT(sSQL)

        '3. Geselecteerde data verwerken
        warenhuizen = New Dictionary(Of String, Warenhuis)()
        Dim oRow As DataRow
        For Each oRow In oDataTable.Rows
            Dim sNaam As String = Convert.ToString(oRow.Item("Naam")).Trim
            Dim sAdres As String = Convert.ToString(oRow.Item("Adres")).Trim
            Dim sGemeente As String = Convert.ToString(oRow.Item("Gemeente")).Trim
            Dim sID As String = Convert.ToString(oRow.Item("WarenhuisID"))

            warenhuizen.Add(sID, New Warenhuis(sID, sNaam, sAdres, sGemeente))
        Next

        Return warenhuizen
    End Function
    Public Shared Function GetGemeentenVanWarenhuizen() As List(Of String)
            '1. Data ophalen
            Dim sSQL As String = "SELECT Distinct gemeente  FROM Warenhuis"
            Dim oDataTable As DataTable = Database.GetDT(sSQL)
    
            '3. Geselecteerde data verwerken
            Dim gemeenten As New List(Of String)(oDataTable.Rows.Count)
            Dim oRow As DataRow
            For Each oRow In oDataTable.Rows
                Dim sGemeente As String = Convert.ToString(oRow.Item("Gemeente")).Trim
                gemeenten.Add(sGemeente)
            Next
    
        Return gemeenten
    End Function
    Public Shared Function GetNamenVanWarenhuizen() As List(Of String)
        '1. Data ophalen
        Dim sSQL As String = "SELECT Distinct naam FROM Warenhuis"
        Dim oDataTable As DataTable = Database.GetDT(sSQL)

        '3. Geselecteerde data verwerken
        Dim namen As New List(Of String)(oDataTable.Rows.Count)
        Dim oRow As DataRow
        For Each oRow In oDataTable.Rows
            Dim sNaam As String = Convert.ToString(oRow.Item("Naam")).Trim
            namen.Add(sNaam)
        Next

        Return namen
    End Function
End Class
