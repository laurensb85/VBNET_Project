﻿Imports Aankopen.data
Imports System.Data.Common
Public Class CategorieDA
    '-- Internal types --
    '-- Fields --
    '-- Properties --
    '-- Constructors --
    Private Sub New()
    End Sub
    '-- Methods --
    Public Shared Function GetCategories() As List(Of Categorie)
        '1. Data ophalen
        Dim sSQL As String = "SELECT * FROM Categorie"
        Dim oDataTable As DataTable = Database.GetDT(sSQL)

        '3. Geselecteerde data verwerken
        Dim categories As New List(Of Categorie)(oDataTable.Rows.Count)
        Dim oRow As DataRow
        For Each oRow In oDataTable.Rows
            Dim sNaam As String = Convert.ToString(oRow.Item("Naam")).Trim
            Dim sID As String = Convert.ToString(oRow.Item("CategorieID"))

            categories.Add(New Categorie(sNaam, sID))
        Next

        Return categories
    End Function

    Public Shared Function GetCategoriesByCategorieId(ByVal sCategorieId As String) As Categorie
        Dim oDR As DbDataReader = Nothing

        Try
            '1. Select en pars
            Dim sSQL As String = "SELECT * FROM Categorie WHERE CategorieID={0}"
            Dim oCategorieIdPar As DbParameter = Database.GetParameter("CategorieID", sCategorieId)
            oDR = Database.GetDR(sSQL, oCategorieIdPar)

            '2. Geselecteerde data verwerken
            While oDR.Read()
                Return vulCategorie(oDR, sCategorieId)
            End While

        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Throw

        Finally
            '4. Reader sluiten
            If oDR IsNot Nothing Then
                oDR.Close()
            End If
        End Try
    End Function

    Public Shared Function vulCategorie(ByVal oDR As DbDataReader, ByVal categorieId As String)
        Dim oCategorie As New Categorie(categorieId)

        oCategorie.ID = Convert.ToString(oDR.Item("CategorieID"))
        oCategorie.Naam = Convert.ToString(oDR.Item("Naam"))

        Return oCategorie
    End Function

    '-- Events --
End Class
