﻿Imports Aankopen.data
Imports System.Data.Common

Public Class ProductWarenhuisDA
    '-- Fields --

    '-- Properties --

    '-- Constructors --
    Private Sub New()
    End Sub

    '-- Methods --
    Public Shared Function GetProductWarenhuizen() As List(Of ProductWarenhuis)
        Dim oDR As DbDataReader = Nothing

        Try
            '1. Data ophalen
            Dim sSQL As String = "SELECT * FROM ProductWarenhuis"
            oDR = Database.GetDR(sSQL)

            '3. Geselecteerde data verwerken
            Dim lstProductWarenhuis As List(Of ProductWarenhuis) = New List(Of ProductWarenhuis)
            While oDR.Read()
                lstProductWarenhuis.Add(vulProductWarenhuis(oDR))
            End While

            '4. Het gevraagde  returnen
            Return lstProductWarenhuis

        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Throw

        Finally
            '5. DR sluiten
            If oDR IsNot Nothing Then
                oDR.Close()
            End If
        End Try
    End Function

    Public Shared Function GetProductWarenhuizenByGemeente(ByVal sCategorieId) As List(Of ProductWarenhuis)
        Dim oDR As DbDataReader = Nothing

        Try
            '1. Data ophalen
            Dim sSQL As String = "SELECT * FROM ProductWarenhuis as pw, Warenhuis as w WHERE w.Gemeente = ? and pw.WarenhuisID = w.WarenhuisID"
            Dim oGemeenteIdPar As DbParameter = Database.GetParameter("GemeenteID", sCategorieId)
            oDR = Database.GetDR(sSQL, oGemeenteIdPar)

            '3. Geselecteerde data verwerken
            Dim lstProductWarenhuis As List(Of ProductWarenhuis) = New List(Of ProductWarenhuis)
            While oDR.Read()
                lstProductWarenhuis.Add(vulProductWarenhuis(oDR))
            End While

            '4. Het gevraagde  returnen
            Return lstProductWarenhuis

        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Throw

        Finally
            '5. DR sluiten
            If oDR IsNot Nothing Then
                oDR.Close()
            End If
        End Try
    End Function

    Private Shared Function vulProductWarenhuis(ByVal oDR As DbDataReader)
        Dim oProductWarenhuis As ProductWarenhuis = New ProductWarenhuis

        oProductWarenhuis.ID = Convert.ToInt32(oDR.Item("ProductWarenhuisID"))
        oProductWarenhuis.Product = ProductDA.GetProducten(oDR.Item("ProductID"))
        oProductWarenhuis.Warenhuis = WarenhuisDA.GetWarenhuizen(oDR.Item("WarenhuisID"))
        oProductWarenhuis.Prijs = Convert.ToDouble(oDR.Item("Prijs"))

        Return oProductWarenhuis
    End Function
End Class
