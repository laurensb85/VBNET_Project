﻿'
'  Creatie : 01-15/08/2008
'
'
'  Auteur : Marleen De Wandel
'
'   Versie 1 : creatie
'   Versie 2 : methoden voor transacties toegevoegd
'   - Methode BeginTransaction  : start een transactie
'   - Overload van methode BuildCommand : maakt Command onder bepaalde transactie
'   - Overload van methode ExecuteSQL : voert gegeven sql onder bepaalde transactie uit
'   - Overload van methode GetDT : haalt DT onder transactie op
'   - Methode FillCommand : vult de eigenschappen van Command object op met SQL en parameters
'   - ReleaseConnection : public
'   Versie 3 : ConnectionBeheer toegevoegd
'   De waarde (True/False) van de appSetting KeepConOpen  bepaalt 
'   of de Connection bij elke DB-actie geopend/gesloten wordt
'   - Property KeepConOpen toegevoegd
'   - GetConnection aangepast : houdt rekening met KeepConOpen
'   - ReleaseConnection(ByVal oCon As DbConnection) : aangepast
'   - ReleaseConnection()  toegevoegd
'
Imports System.Data.Common
Imports System.Configuration
Imports SqlParPlaceholders

Public Class Database
    '-- Fields --
    'Bevat de Connection indien deze open blijft
    Private Shared moConnection As DbConnection = Nothing

    Private Shared moDBProviderFactory As DbProviderFactory
    Private Shared moPlaceholderFactory As PlaceholderFactory
    '-- Properties --
    Private Shared ReadOnly Property ConnectionString() As String
        Get
            Return ConfigurationManager.ConnectionStrings.Item("ConnectionString").ConnectionString
        End Get
    End Property
    Private Shared ReadOnly Property ProviderName() As String
        Get
            Return ConfigurationManager.ConnectionStrings.Item("ConnectionString").ProviderName
        End Get
    End Property
    'KeepConOpen appSetting ophalen
    Private Shared ReadOnly Property KeepConOpen() As Boolean
        Get
            Return Convert.ToBoolean(ConfigurationManager.AppSettings.Item("KeepConOpen"))
        End Get
    End Property

    '-- Constructors --
    Shared Sub New()
        'Haal de Factories op
        moDBProviderFactory = DbProviderFactories.GetFactory(ProviderName)
        moPlaceholderFactory = PlaceholderFactories.GetFactory(ProviderName)
    End Sub

    Private Sub New()
    End Sub
    '-- Methoden --
#Region "Connectiebeheer"
    Private Shared Function GetConnection() As DbConnection
        If KeepConOpen Then
            'De applicatie gebruikt steeds dezelfde connection
            If moConnection Is Nothing Then
                'Eerste keer is er nog geen Connection
                moConnection = moDBProviderFactory.CreateConnection()
                moConnection.ConnectionString = ConnectionString
                moConnection.Open()
                Console.WriteLine("Connection openen")
            End If
            Return moConnection
        Else
            'Elke DB-actie eigen Connection
            Dim oConnection As DbConnection
            oConnection = moDBProviderFactory.CreateConnection()
            oConnection.ConnectionString = ConnectionString
            oConnection.Open()
            Console.WriteLine("Connection openen")
            Return oConnection
        End If
    End Function
    Public Shared Sub ReleaseConnection(ByVal oCon As DbConnection)
        If Not KeepConOpen Then
            If oCon IsNot Nothing Then
                oCon.Close()
                Console.WriteLine("Connection sluiten")
            End If
        End If
    End Sub
    Public Shared Sub ReleaseConnection()
        If moConnection IsNot Nothing Then
            moConnection.Close()
            Console.WriteLine("Connection sluiten")
        End If
    End Sub
#End Region
#Region "Beheer zonder transacties"

    Private Shared Function BuildCommand(ByVal sSql As String, ByVal ParamArray dbParams() As DbParameter) As DbCommand
        '1. Connectie maken
        Dim oCon As DbConnection = GetConnection()

        '2 Command object aanmaken
        Dim oCommand As DbCommand = oCon.CreateCommand

        '3. Command object opvullen
        FillCommand(oCommand, sSql, dbParams)

        '5. Returnen
        Return oCommand
    End Function
    Public Shared Function GetDT(ByVal sSql As String, ByVal ParamArray dbParams() As DbParameter) As DataTable
        Dim oCom As DbCommand = Nothing
        Try
            '1. Command object aanmaken
            oCom = BuildCommand(sSql, dbParams)

            '2. DataAdapter aanmaken en er het Command-object aan doorgeven
            Dim oDA As DbDataAdapter = moDBProviderFactory.CreateDataAdapter()
            oDA.SelectCommand = oCom

            '3. De data selecteren en naar een datatable overbrengen
            Dim oDT As New DataTable
            oDA.Fill(oDT)

            '4. De datatable returnen
            Return oDT
        Finally
            'Connectie sluiten
            ReleaseConnection(oCom.Connection)
        End Try
    End Function
    Public Shared Function GetDR(ByVal sSql As String, _
                    ByVal ParamArray dbParams() As DbParameter) As DbDataReader
        Dim oCom As DbCommand = Nothing
        Dim oDR As DbDataReader = Nothing
        Try
            '1. Command object aanmaken
            oCom = BuildCommand(sSql, dbParams)

            '2. Select op de database uitvoeren
            If KeepConOpen Then
                oDR = oCom.ExecuteReader(CommandBehavior.Default)
            Else
                oDR = oCom.ExecuteReader(CommandBehavior.CloseConnection)
            End If

            '3. De Reader returnen
            Return oDR
        Catch ex As Exception
            'Connectie enkel hier reeds sluiten indien geen DbDataReader
            If oDR Is Nothing Then
                ReleaseConnection(oCom.Connection)
            End If
            'Opnieuw gooien zodanig dat cliënt ook op de hoogte is
            Throw
        End Try
    End Function
    'Select met maar 1 resultaat
    Public Shared Function ExecuteScalar(ByVal sSql As String, ByVal ParamArray dbParams() As DbParameter) As Object
        Dim oCom As DbCommand = Nothing
        Try
            '1. Command object aanmaken
            oCom = BuildCommand(sSql, dbParams)

            '2. SQL op DB uitvoeren
            Dim oObject As Object = oCom.ExecuteScalar()

            '3. Resultaat returnen
            Return oObject
        Finally
            '4.Connectie sluiten
            ReleaseConnection(oCom.Connection)
        End Try

    End Function
    'SQL zonder terugkeer resultaat uitvoeren
    Public Shared Sub ExecuteSQL(ByVal sSql As String, ByVal ParamArray dbParams() As DbParameter)
        Dim oCom As DbCommand = Nothing
        Try
            '1. Command object aanmaken
            oCom = BuildCommand(sSql, dbParams)

            '2. SQL op DB uitvoeren
            oCom.ExecuteNonQuery()
        Finally
            '3.Connectie sluiten
            ReleaseConnection(oCom.Connection)
        End Try
    End Sub

#End Region
#Region "Common routines"

    Public Shared Function GetParameter() As DbParameter
        Return moDBProviderFactory.CreateParameter()
    End Function
    Public Shared Function GetParameter(ByVal sNaam As String, ByVal oWaarde As Object) As DbParameter
        Dim oPar As DbParameter = moDBProviderFactory.CreateParameter()
        oPar.ParameterName = sNaam
        oPar.Value = oWaarde
        Return oPar
    End Function
    Private Shared Sub FillCommand(ByVal oCommand As DbCommand, ByVal sSql As String, ByVal ParamArray dbParams() As DbParameter)
        '1. CommandType
        oCommand.CommandType = CommandType.Text

        '2. Indien aanwezig de parameters verwerken
        If dbParams.Length > 0 Then
            '   -   Parameter placeholders in SQL statement plaatsen
            Dim placeholders As New List(Of String)(dbParams.Length)
            For Each oParam As DbParameter In dbParams
                Dim sPH As String = moPlaceholderFactory.CreateParameterPH(oParam.ParameterName)
                placeholders.Add(sPH)
            Next
            sSql = String.Format(sSql, placeholders.ToArray())
            '   - Parameters zelf aan lijst van parameters toevoegen
            For Each oPar As DbParameter In dbParams
                oCommand.Parameters.Add(oPar)
            Next
        End If

        '3. CommandText
        oCommand.CommandText = sSql
    End Sub

#End Region

#Region "Beheer met transacties"
    'Transactie starten,
    Public Shared Function BeginTransaction() As DbTransaction
        Dim oCon As DbConnection = Nothing
        Try
            '1. Connectie maken en openen
            oCon = GetConnection()

            '2. Transactie starten en terugkeren
            Return oCon.BeginTransaction()

        Catch ex As Exception
            'Het ging mis dus connectie opnieuw sluiten
            ReleaseConnection(oCon)
            Throw
        End Try
    End Function
    'Command maken op basis van transactie, SQL en parameters
    Private Shared Function BuildCommand(ByVal oTrans As DbTransaction, ByVal sSql As String, ByVal ParamArray dbParams() As DbParameter) As DbCommand
        '1. Command object aanmaken
        Dim oCon As DbConnection = oTrans.Connection
        Dim oCommand As DbCommand = oCon.CreateCommand
        oCommand.Transaction = oTrans

        '2. Command object opvullen
        FillCommand(oCommand, sSql, dbParams)

        '3. Returnen
        Return oCommand
    End Function

    'SQL zonder terugkeer resultaat uitvoeren binnen transactie
    Public Shared Sub ExecuteSQL(ByVal oTrans As DbTransaction, ByVal sSQL As String, ByVal ParamArray dbParams() As DbParameter)
        '1. Command object aanmaken
        Dim oCommand As DbCommand = Nothing
        oCommand = BuildCommand(oTrans, sSQL, dbParams)

        '2. SQL uitvoeren
        oCommand.ExecuteNonQuery()
    End Sub
    'DataTable ophalen binnen transactie
    Public Shared Function GetDT(ByVal oTrans As DbTransaction, ByVal sSQL As String, ByVal ParamArray dbParams() As DbParameter) As DataTable
        '1. Command object aanmaken
        Dim oCommand As DbCommand = BuildCommand(oTrans, sSQL, dbParams)

        '2. DataAdapter aanmaken en er het Command-object aan doorgeven
        Dim oDataAdapter As DbDataAdapter = moDBProviderFactory.CreateDataAdapter()
        oDataAdapter.SelectCommand = oCommand

        '3. De data selecteren en naar een datatable overbrengen
        Dim oDataTable As New DataTable
        oDataAdapter.Fill(oDataTable)

        '4. De datatable returnen
        Return oDataTable
    End Function
#End Region
End Class


