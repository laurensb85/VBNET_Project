﻿'Q102 - 13/01/2008 - NM
'Voornaam : Mathew
'Naam : Hucks
'Labo-groep : L1

Imports Aankopen.DA
Imports Aankopen.data

Public Class MainForm

    Private moGekozenProduct As String = ""
    Private moGekozenOmschrijving As String = ""
    Private moGekozenPrijs As String = ""
    Private moGekozenWarenhuis As String = ""

    Private moGekozenDelProduct As Object = Nothing

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Vullen van controls
        vulCategorieFilter()
        vulGemeenteFilter()
        vulListViewProducten()
    End Sub

#Region "Opvullen controls"
    'Standaard
    Private Sub vulCategorieFilter()
        cboCategorieFilter.Items.Clear()

        Dim lstCategorien As New List(Of Categorie)
        lstCategorien = CategorieDA.GetCategories()

        For Each oCategorie As Categorie In lstCategorien
            cboCategorieFilter.Items.Add(oCategorie)
        Next
    End Sub

    Private Sub vulGemeenteFilter()
        cboGemeenteFilter.Items.Clear()

        Dim lstGemeenten As New List(Of String)
        lstGemeenten = WarenhuisDA.GetGemeentenVanWarenhuizen()

        For Each sGemeente As String In lstGemeenten
            cboGemeenteFilter.Items.Add(sGemeente)
        Next
    End Sub

    Private Sub vulListViewProducten()
        lvwProducten.Items.Clear()

        Dim lstProductWarenhuis As New List(Of ProductWarenhuis)
        lstProductWarenhuis = ProductWarenhuisDA.GetProductWarenhuizen()

        For Each oProductenWarenhuis As ProductWarenhuis In lstProductWarenhuis
            Dim oItem As New ListViewItem(oProductenWarenhuis.Product.Naam)
            oItem.SubItems.Add(oProductenWarenhuis.Product.Omschrijving)
            oItem.SubItems.Add(oProductenWarenhuis.Prijs)
            oItem.SubItems.Add(oProductenWarenhuis.Warenhuis.Naam)

            lvwProducten.Items.Add(oItem)
        Next
    End Sub

    'Via filter
    Private Sub vulListViewProductenGemeenteFilter()
        lvwProducten.Items.Clear()

        Dim sGemeente As String = cboGemeenteFilter.SelectedItem

        Dim lstProductWarenhuis As New List(Of ProductWarenhuis)
        lstProductWarenhuis = ProductWarenhuisDA.GetProductWarenhuizenByGemeente(sGemeente)

        For Each oProductenWarenhuis As ProductWarenhuis In lstProductWarenhuis
            Dim oItem As New ListViewItem(oProductenWarenhuis.Product.Naam)
            oItem.SubItems.Add(oProductenWarenhuis.Product.Omschrijving)
            oItem.SubItems.Add(oProductenWarenhuis.Prijs)
            oItem.SubItems.Add(oProductenWarenhuis.Warenhuis.Naam)

            lvwProducten.Items.Add(oItem)
        Next
    End Sub
#End Region

#Region "Buttons"
    Private Sub cboCategorieFilter_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCategorieFilter.SelectedIndexChanged

    End Sub

    Private Sub cboGemeenteFilter_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboGemeenteFilter.SelectedIndexChanged
        vulListViewProductenGemeenteFilter()
    End Sub

    Private Sub btnAankoopToevoegen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAankoopToevoegen.Click
        productOverBrengen()
    End Sub

    Private Sub btnAankoopVerwijderen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAankoopVerwijderen.Click
        productVerwijderen()
    End Sub
#End Region

    Private Sub productOverBrengen()
        aanmakenGroepen()

        Dim oItem As New ListViewItem(moGekozenProduct)
        oItem.SubItems.Add(moGekozenOmschrijving)
        oItem.SubItems.Add(moGekozenPrijs)
        oItem.SubItems.Add(txtAantalVanProduct.Text)
        oItem.Group = lvwAankopen.Groups(moGekozenWarenhuis)

        lvwAankopen.Items.Add(oItem)
    End Sub

    Private Sub productVerwijderen()
        lvwAankopen.Items.Remove(moGekozenDelProduct)
    End Sub

    Private Sub aanmakenGroepen()
        'groepnaam = categorienamen
        Dim lstWarenhuizen As New List(Of String)
        lstWarenhuizen = WarenhuisDA.GetNamenVanWarenhuizen()

        For Each sWarenhuis As String In lstWarenhuizen
            'groepen aanmaken
            Dim oGrp As ListViewGroup = New ListViewGroup
            oGrp.Name = sWarenhuis
            oGrp.Header = sWarenhuis

            lvwAankopen.Groups.Add(oGrp)
        Next
    End Sub

    Private Sub lvwProducten_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwProducten.SelectedIndexChanged
        Dim SelectedItems As ListView.SelectedListViewItemCollection = CType(sender, ListView).SelectedItems
        If (SelectedItems.Count > 0 And SelectedItems.Count < 2) Then

            moGekozenProduct = SelectedItems(0).SubItems(0).Text
            moGekozenOmschrijving = SelectedItems(0).SubItems(1).Text
            moGekozenPrijs = SelectedItems(0).SubItems(2).Text
            moGekozenWarenhuis = SelectedItems(0).SubItems(3).Text

            lbldataVanProduct.Text = SelectedItems(0).SubItems(0).Text & " " & SelectedItems(0).SubItems(3).Text
        End If
    End Sub

    Private Sub lvwAankopen_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwAankopen.SelectedIndexChanged
        Dim SelectedItems As ListView.SelectedListViewItemCollection = CType(sender, ListView).SelectedItems
        If (SelectedItems.Count > 0 And SelectedItems.Count < 2) Then

            moGekozenDelProduct = SelectedItems(0)
        End If
    End Sub
End Class