﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.Label1 = New System.Windows.Forms.Label
        Me.cboCategorieFilter = New System.Windows.Forms.ComboBox
        Me.lvwProducten = New System.Windows.Forms.ListView
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader4 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader
        Me.lvwAankopen = New System.Windows.Forms.ListView
        Me.ColumnHeader5 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader6 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader7 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader9 = New System.Windows.Forms.ColumnHeader
        Me.imlAankopen = New System.Windows.Forms.ImageList(Me.components)
        Me.txtAantalVanProduct = New System.Windows.Forms.TextBox
        Me.lbldataVanProduct = New System.Windows.Forms.Label
        Me.btnAankoopToevoegen = New System.Windows.Forms.Button
        Me.iml = New System.Windows.Forms.ImageList(Me.components)
        Me.btnAankoopVerwijderen = New System.Windows.Forms.Button
        Me.btnBoodschappenlijstAanmaken = New System.Windows.Forms.Button
        Me.cboGemeenteFilter = New System.Windows.Forms.ComboBox
        Me.grpProducten = New System.Windows.Forms.GroupBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.grpAankopen = New System.Windows.Forms.GroupBox
        Me.btnSparen = New System.Windows.Forms.Button
        Me.grpProducten.SuspendLayout()
        Me.grpAankopen.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 18)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Categorie filter"
        '
        'cboCategorieFilter
        '
        Me.cboCategorieFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCategorieFilter.FormattingEnabled = True
        Me.cboCategorieFilter.Location = New System.Drawing.Point(110, 15)
        Me.cboCategorieFilter.Name = "cboCategorieFilter"
        Me.cboCategorieFilter.Size = New System.Drawing.Size(135, 24)
        Me.cboCategorieFilter.TabIndex = 4
        '
        'lvwProducten
        '
        Me.lvwProducten.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwProducten.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader4, Me.ColumnHeader2, Me.ColumnHeader3})
        Me.lvwProducten.FullRowSelect = True
        Me.lvwProducten.HideSelection = False
        Me.lvwProducten.Location = New System.Drawing.Point(12, 50)
        Me.lvwProducten.MultiSelect = False
        Me.lvwProducten.Name = "lvwProducten"
        Me.lvwProducten.Size = New System.Drawing.Size(538, 184)
        Me.lvwProducten.TabIndex = 5
        Me.lvwProducten.UseCompatibleStateImageBehavior = False
        Me.lvwProducten.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Productnaam"
        Me.ColumnHeader1.Width = 102
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Omschrijving"
        Me.ColumnHeader4.Width = 201
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Prijs"
        Me.ColumnHeader2.Width = 59
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Warenhuis"
        Me.ColumnHeader3.Width = 237
        '
        'lvwAankopen
        '
        Me.lvwAankopen.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwAankopen.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader9})
        Me.lvwAankopen.FullRowSelect = True
        Me.lvwAankopen.HideSelection = False
        Me.lvwAankopen.Location = New System.Drawing.Point(10, 49)
        Me.lvwAankopen.MultiSelect = False
        Me.lvwAankopen.Name = "lvwAankopen"
        Me.lvwAankopen.Size = New System.Drawing.Size(540, 117)
        Me.lvwAankopen.TabIndex = 7
        Me.lvwAankopen.UseCompatibleStateImageBehavior = False
        Me.lvwAankopen.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Productnaam"
        Me.ColumnHeader5.Width = 112
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Omschrijving"
        Me.ColumnHeader6.Width = 259
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Prijs"
        Me.ColumnHeader7.Width = 59
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "Aantal"
        '
        'imlAankopen
        '
        Me.imlAankopen.ImageStream = CType(resources.GetObject("imlAankopen.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlAankopen.TransparentColor = System.Drawing.Color.Transparent
        Me.imlAankopen.Images.SetKeyName(0, "Basket.bmp")
        '
        'txtAantalVanProduct
        '
        Me.txtAantalVanProduct.Location = New System.Drawing.Point(6, 21)
        Me.txtAantalVanProduct.Name = "txtAantalVanProduct"
        Me.txtAantalVanProduct.Size = New System.Drawing.Size(59, 22)
        Me.txtAantalVanProduct.TabIndex = 8
        '
        'lbldataVanProduct
        '
        Me.lbldataVanProduct.AutoSize = True
        Me.lbldataVanProduct.Location = New System.Drawing.Point(88, 21)
        Me.lbldataVanProduct.Name = "lbldataVanProduct"
        Me.lbldataVanProduct.Size = New System.Drawing.Size(156, 16)
        Me.lbldataVanProduct.TabIndex = 10
        Me.lbldataVanProduct.Text = "-------------------------------------"
        '
        'btnAankoopToevoegen
        '
        Me.btnAankoopToevoegen.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAankoopToevoegen.ImageIndex = 1
        Me.btnAankoopToevoegen.ImageList = Me.iml
        Me.btnAankoopToevoegen.Location = New System.Drawing.Point(467, 14)
        Me.btnAankoopToevoegen.Name = "btnAankoopToevoegen"
        Me.btnAankoopToevoegen.Size = New System.Drawing.Size(24, 25)
        Me.btnAankoopToevoegen.TabIndex = 11
        Me.btnAankoopToevoegen.UseVisualStyleBackColor = True
        '
        'iml
        '
        Me.iml.ImageStream = CType(resources.GetObject("iml.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.iml.TransparentColor = System.Drawing.Color.Magenta
        Me.iml.Images.SetKeyName(0, "Document.bmp")
        Me.iml.Images.SetKeyName(1, "Bestel.bmp")
        Me.iml.Images.SetKeyName(2, "Delete.bmp")
        Me.iml.Images.SetKeyName(3, "Money.bmp")
        '
        'btnAankoopVerwijderen
        '
        Me.btnAankoopVerwijderen.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAankoopVerwijderen.ImageIndex = 2
        Me.btnAankoopVerwijderen.ImageList = Me.iml
        Me.btnAankoopVerwijderen.Location = New System.Drawing.Point(497, 12)
        Me.btnAankoopVerwijderen.Name = "btnAankoopVerwijderen"
        Me.btnAankoopVerwijderen.Size = New System.Drawing.Size(24, 28)
        Me.btnAankoopVerwijderen.TabIndex = 11
        Me.btnAankoopVerwijderen.UseVisualStyleBackColor = True
        '
        'btnBoodschappenlijstAanmaken
        '
        Me.btnBoodschappenlijstAanmaken.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBoodschappenlijstAanmaken.ImageIndex = 0
        Me.btnBoodschappenlijstAanmaken.ImageList = Me.iml
        Me.btnBoodschappenlijstAanmaken.Location = New System.Drawing.Point(527, 12)
        Me.btnBoodschappenlijstAanmaken.Name = "btnBoodschappenlijstAanmaken"
        Me.btnBoodschappenlijstAanmaken.Size = New System.Drawing.Size(23, 27)
        Me.btnBoodschappenlijstAanmaken.TabIndex = 11
        Me.btnBoodschappenlijstAanmaken.UseVisualStyleBackColor = True
        '
        'cboGemeenteFilter
        '
        Me.cboGemeenteFilter.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboGemeenteFilter.FormattingEnabled = True
        Me.cboGemeenteFilter.Location = New System.Drawing.Point(377, 15)
        Me.cboGemeenteFilter.Name = "cboGemeenteFilter"
        Me.cboGemeenteFilter.Size = New System.Drawing.Size(173, 24)
        Me.cboGemeenteFilter.TabIndex = 12
        '
        'grpProducten
        '
        Me.grpProducten.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpProducten.Controls.Add(Me.Label2)
        Me.grpProducten.Controls.Add(Me.Label1)
        Me.grpProducten.Controls.Add(Me.cboGemeenteFilter)
        Me.grpProducten.Controls.Add(Me.cboCategorieFilter)
        Me.grpProducten.Controls.Add(Me.lvwProducten)
        Me.grpProducten.Location = New System.Drawing.Point(7, 12)
        Me.grpProducten.Name = "grpProducten"
        Me.grpProducten.Size = New System.Drawing.Size(559, 249)
        Me.grpProducten.TabIndex = 13
        Me.grpProducten.TabStop = False
        Me.grpProducten.Text = "Producten"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(250, 18)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Gemeente filter"
        '
        'grpAankopen
        '
        Me.grpAankopen.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpAankopen.Controls.Add(Me.btnSparen)
        Me.grpAankopen.Controls.Add(Me.txtAantalVanProduct)
        Me.grpAankopen.Controls.Add(Me.lbldataVanProduct)
        Me.grpAankopen.Controls.Add(Me.lvwAankopen)
        Me.grpAankopen.Controls.Add(Me.btnBoodschappenlijstAanmaken)
        Me.grpAankopen.Controls.Add(Me.btnAankoopToevoegen)
        Me.grpAankopen.Controls.Add(Me.btnAankoopVerwijderen)
        Me.grpAankopen.Location = New System.Drawing.Point(7, 267)
        Me.grpAankopen.Name = "grpAankopen"
        Me.grpAankopen.Size = New System.Drawing.Size(556, 193)
        Me.grpAankopen.TabIndex = 14
        Me.grpAankopen.TabStop = False
        Me.grpAankopen.Text = "Aankopen"
        '
        'btnSparen
        '
        Me.btnSparen.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSparen.ImageIndex = 3
        Me.btnSparen.ImageList = Me.iml
        Me.btnSparen.Location = New System.Drawing.Point(436, 14)
        Me.btnSparen.Name = "btnSparen"
        Me.btnSparen.Size = New System.Drawing.Size(25, 23)
        Me.btnSparen.TabIndex = 12
        Me.btnSparen.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(578, 447)
        Me.Controls.Add(Me.grpAankopen)
        Me.Controls.Add(Me.grpProducten)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimumSize = New System.Drawing.Size(586, 483)
        Me.Name = "MainForm"
        Me.Text = "Maak je boodschappenlijst"
        Me.grpProducten.ResumeLayout(False)
        Me.grpProducten.PerformLayout()
        Me.grpAankopen.ResumeLayout(False)
        Me.grpAankopen.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboCategorieFilter As System.Windows.Forms.ComboBox
    Friend WithEvents lvwProducten As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvwAankopen As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtAantalVanProduct As System.Windows.Forms.TextBox
    Friend WithEvents lbldataVanProduct As System.Windows.Forms.Label
    Friend WithEvents btnAankoopToevoegen As System.Windows.Forms.Button
    Friend WithEvents btnAankoopVerwijderen As System.Windows.Forms.Button
    Friend WithEvents btnBoodschappenlijstAanmaken As System.Windows.Forms.Button
    Friend WithEvents iml As System.Windows.Forms.ImageList
    Friend WithEvents cboGemeenteFilter As System.Windows.Forms.ComboBox
    Friend WithEvents grpProducten As System.Windows.Forms.GroupBox
    Friend WithEvents grpAankopen As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents imlAankopen As System.Windows.Forms.ImageList
    Friend WithEvents btnSparen As System.Windows.Forms.Button
End Class
