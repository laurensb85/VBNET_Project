﻿'
'  Copyright : Marleen De Wandel
'
Public Class MySqlPlaceholderFactory
    Inherits PlaceholderFactory

    Public Overrides Function CreateParameterPH(ByVal sParameterName As String) As String
        Return "?" & sParameterName
    End Function
End Class
