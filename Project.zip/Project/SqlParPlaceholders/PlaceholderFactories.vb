﻿'
'  Copyright : Marleen De Wandel
'
Public Class PlaceholderFactories

    Public Shared Function GetFactory(ByVal sProviderName As String) As PlaceholderFactory
        Select Case sProviderName
            Case "System.Data.SqlClient"
                Return New SqlClientPlaceholderFactory()
            Case "System.Data.OleDb"
                Return New OleDbPlaceholderFactory()
            Case "MySql.Data.MySqlClient"
                Return New MySqlPlaceholderFactory()
            Case Else
                Return Nothing
        End Select
    End Function

End Class
