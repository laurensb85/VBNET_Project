﻿'
'  Copyright : Marleen De Wandel
'
Public Class OleDbPlaceholderFactory
    Inherits PlaceholderFactory

    Public Overrides Function CreateParameterPH(ByVal sParameterName As String) As String
        Return "?"
    End Function
End Class
