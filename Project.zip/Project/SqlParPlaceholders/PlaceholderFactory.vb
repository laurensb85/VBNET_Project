﻿'
'  Copyright : Marleen De Wandel
'
Public MustInherit Class PlaceholderFactory
    Public MustOverride Function CreateParameterPH(ByVal sParameterName As String) As String
End Class
