﻿Public Class ProductWarenhuis
    Private miID As Integer
    Private moProduct As Product
    Private moWarenhuis As Warenhuis
    Private mdPrijs As Double

    '-- Properties --
    Public Property ID() As Integer
        Get
            Return Me.miID
        End Get
        Set(ByVal Value As Integer)
            Me.miID = Value
        End Set
    End Property

    Public Property Product() As Product
        Get
            Return Me.moProduct
        End Get
        Set(ByVal Value As Product)
            Me.moProduct = Value
        End Set
    End Property

    Public Property Warenhuis() As Warenhuis
        Get
            Return Me.moWarenhuis
        End Get
        Set(ByVal Value As Warenhuis)
            Me.moWarenhuis = Value
        End Set
    End Property

    Public Property Prijs() As Double
        Get
            Return Me.mdPrijs
        End Get
        Set(ByVal Value As Double)
            Me.mdPrijs = Value
        End Set
    End Property

    '-- Constructors --
    Public Sub New(ByVal iID As Integer, ByVal oProduct As Product, ByVal oWarenhuis As Warenhuis, ByVal dPrijs As Double)
        Me.ID = iID
        Me.Product = oProduct
        Me.Warenhuis = oWarenhuis
        Me.Prijs = dPrijs
    End Sub

    Public Sub New()

    End Sub
End Class
