﻿Public Class Product

    '-- Internal types --
    '-- Fields --
    Private msID As String
    Private msNaam As String
    Private msOmschrijving As String
    Private msCategorieID As String

    Private mdPrijs As Double
    Private moWarenhuis As Warenhuis
    Private moCategorie As Categorie

    '-- Properties --
    Public Property ID() As String
        Get
            Return msID
        End Get
        Set(ByVal value As String)
            msID = value
        End Set
    End Property

    Public Property Naam() As String
        Get
            Return msNaam
        End Get
        Set(ByVal value As String)
            msNaam = value
        End Set
    End Property

    Public Property Omschrijving() As String
        Get
            Return msOmschrijving
        End Get
        Set(ByVal value As String)
            msOmschrijving = value
        End Set
    End Property

    Public Property CategorieID() As String
        Get
            Return msCategorieID
        End Get
        Set(ByVal value As String)
            msCategorieID = value
        End Set
    End Property

    Public Property Prijs() As Double
        Get
            Return mdPrijs
        End Get
        Set(ByVal value As Double)
            mdPrijs = value
        End Set
    End Property

    Public Property Warenhuis() As Warenhuis
        Get
            Return moWarenhuis
        End Get
        Set(ByVal value As Warenhuis)
            moWarenhuis = value
        End Set
    End Property

    Public Property Categorie() As Categorie
        Get
            Return moCategorie
        End Get
        Set(ByVal value As Categorie)
            moCategorie = value
        End Set
    End Property

    '-- Constructors --
    Public Sub New(ByVal sID As String, ByVal sProductnaam As String, ByVal sOmschrijving As String, ByVal sCatID As String)
        Me.Omschrijving = sOmschrijving
        Me.ID = sID
        Me.Naam = sProductnaam
        Me.CategorieID = sCatID
    End Sub

    Public Sub New(ByVal sID As String)
        Me.ID = sID
    End Sub

    '-- Methods --
    Public Overrides Function ToString() As String
        Return Me.Naam
    End Function
    '-- Events --

End Class
