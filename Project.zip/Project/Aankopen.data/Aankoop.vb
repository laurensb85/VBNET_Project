﻿Public Class Aankoop
    Implements IComparable(Of Aankoop)

    '-- Internal types --
    '-- Fields --
    Private moProduct As Product
    Private miAantal As Integer

    '-- Properties --
    Public Property Product() As Product
        Get
            Return moProduct
        End Get
        Set(ByVal value As Product)
            moProduct = value
        End Set
    End Property

    Public Property Aantal() As Integer
        Get
            Return miAantal
        End Get
        Set(ByVal value As Integer)
            miAantal = value
        End Set
    End Property

    '-- Constructors --
    Public Sub New(ByVal oProduct As Product, ByVal iAantal As Integer)
        Me.Product = oProduct
        Me.Aantal = iAantal
    End Sub
    '-- Methods --
    Public Function CompareTo(ByVal other As Aankoop) As Integer Implements System.IComparable(Of Aankoop).CompareTo
        If other Is Nothing Then Return 0
        'Aankopen volgens naam van warenhuis ordenen
        If Me.Product.Warenhuis IsNot Nothing AndAlso other.Product.Warenhuis IsNot Nothing Then
            Return Me.Product.Warenhuis.Naam.CompareTo(other.Product.Warenhuis.Naam)
        Else
            Return 0
        End If
    End Function

    '-- Events --



End Class
