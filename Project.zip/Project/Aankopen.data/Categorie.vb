﻿Public Class Categorie
    '-- Internal types --
    '-- Fields --
    Private msNaam As String
    Private msID As String

    '-- Properties --
    Public Property Naam() As String
        Get
            Return msNaam
        End Get
        Set(ByVal value As String)
            msNaam = value
        End Set
    End Property

    Public Property ID() As String
        Get
            Return msID
        End Get
        Set(ByVal value As String)
            msID = value
        End Set
    End Property
    '-- Constructors --
    Public Sub New(ByVal sNaam As String, ByVal sID As String)
        Me.ID = sID
        Me.Naam = sNaam
    End Sub

    Public Sub New(ByVal sId As String)

    End Sub

    '-- Methods --
    Public Overrides Function ToString() As String
        Return Me.Naam
    End Function
    '-- Events --


End Class
