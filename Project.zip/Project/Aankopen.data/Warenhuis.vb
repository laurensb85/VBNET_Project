﻿Public Class Warenhuis
    '-- Internal types --
    '-- Fields --
    Private msNaam As String
    Private msAdres As String
    Private msGemeente As String
    Private msWarenhuisID As String
    '-- Properties --
    Public Property Naam() As String
        Get
            Return msNaam
        End Get
        Set(ByVal value As String)
            msNaam = value
        End Set
    End Property
    Public Property Adres() As String
        Get
            Return msAdres
        End Get
        Set(ByVal value As String)
            msAdres = value
        End Set
    End Property
    Public Property Gemeente() As String
        Get
            Return msGemeente
        End Get
        Set(ByVal value As String)
            msGemeente = value
        End Set
    End Property
    Public Property ID() As String
        Get
            Return msWarenhuisID
        End Get
        Set(ByVal value As String)
            msWarenhuisID = value
        End Set
    End Property
    '-- Constructors --
    Public Sub New(ByVal sID As Integer, ByVal sNaam As String, ByVal sAdres As String, ByVal sGemeente As String)
        Me.ID = sID
        Me.Naam = sNaam
        Me.Adres = sAdres
        Me.Gemeente = sGemeente
    End Sub
    '-- Methods --
    Public Overrides Function ToString() As String
        Return Me.Naam & " - " & Me.Gemeente
    End Function
    '-- Events --

End Class
